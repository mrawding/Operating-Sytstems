// CISC_361_proj1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdbool.h"
#include "Song.h"

#define BUFFERSIZE 255

struct Song* Song(char *name,char* year, char* artist, int time);
struct Song* addSong(struct Song* node,char* year,int runtime,char *name, char*artist);
void printStars();
void printMenu();
void printListf(struct Song* node);
void printListb(struct Song *node);
int deleteSong(struct Song* head, struct Song* last);
void deleteSongContents(struct Song* song);

//Song constructor
struct Song* Song(char* name,char* year, char* artist, int time)

{
	printf("creating song\n");
	//allocate dynamic memory and set attributes
	struct Song* song =(struct Song*)malloc(sizeof(struct Song));
	song->artistName = artist;
	song->runTime = time;
	song->year = year;
	song->songName = name;
	song->next = NULL;
	song->prev = NULL;
	printf("Song created\n");
	return song;


}
//This function prompts users to delete a song and returns an integer value for the specific case to be handled
int deleteSong(struct Song* head,struct Song* tail)
// temporary node to hold first song in playlist
{	struct Song* tmp = head;
	char* str;
	char* art;
	// prompts user for name of song
	printf("Please enter name of song you wish to delete: ");
	// stores song in string
	char buffer[BUFFERSIZE];
	if(fgets(buffer,BUFFERSIZE,stdin) != NULL)
	{	
		 int len = (int)strlen(buffer);
		 str = (char*)malloc(len+1);
                 buffer[len-1] = '\0';
                 strcpy(str,buffer);
	}
	// prompts user for name of artist
	printf("Please enter artist's name: ");
	//stores sname in string
        if(fgets(buffer,BUFFERSIZE,stdin) != NULL)
        {	 int len = (int)strlen(buffer);
                 art = (char*)malloc(len+1);
                 buffer[len-1] = '\0';
                 strcpy(art,buffer);
        }
	// flag for if a song is to be deleted or now
	bool deleteFlag = false;
	// traverses list from beginning to find song
	while(tmp!=NULL)
	{	
		// compares artist name and song name, cmp = 0 if both match
		int cmp = strcmp(tmp->songName,str) + strcmp(tmp->artistName,art);
		//free string memory
		if(cmp == 0)
		{
			// deleting head of list, executed in main()
			if(tmp == head)
			{
				return 2;
			}
			// deleting tail of list, executed in main()
			else if(tmp == tail)
			{
				return 3;
			}
			// deleting neither head or tail, executed here
			else
			{	
				struct Song* tmp2 = tmp->next;
				struct Song* tmp3 = tmp->prev;
				tmp3->next = tmp2;
				tmp2->prev = tmp3;
				deleteSongContents(tmp);
				deleteFlag = true;
				free(tmp);
				break;
			}
		}
		tmp = tmp->next;
	}
	// if song was deleted
	if(deleteFlag)
	{
		printf("Song Successfully Deleted!");
		return 0;
	}
	// song not found, returns 1 which runs the function again
	else
	{
		printf("Song not found, please try again");
		return 1;
	}
}
						
		
//deletes contents of song
void deleteSongContents(struct Song* song)
{
	free(song->songName);
	free(song->artistName);
	free(song->year);
}


// Adds song to end of the list
struct Song* addSong(struct Song* node,char* year, int runtime, char* name, char* artist)
{
	struct Song* tmp = Song(name,year,artist,runtime);
	node->next= tmp;
	tmp->prev = node;
	return tmp; 
}
//Prints the contents in doubly linked list from beginning to end
void printListf(struct Song* node)
{	
	while(node!=NULL)
	{	printStars();
		printf("Song Name: ");
		printf("%s\n",node->songName);
		printf("Artist: ");
		printf("%s\n",node->artistName);
		printf("Year: ");
		printf("%s\n",node->year);
		printf("Runtime: ");
		printf("%d\n",node->runTime);
		printStars();
		node = node->next;
	}
}

//Prints the contents in doubly linked list from last to first
void printListb(struct Song* node)
{
        while(node!=NULL)
        {       printStars();
                printf("Song Name: ");
                printf("%s\n",node->songName);
                printf("Artist: ");
                printf("%s\n",node->artistName);
		printf("Year: ");
		printf("%s\n",node->year);
                printf("Runtime: ");
                printf("%d\n",node->runTime);
                printStars();
                node = node->prev;
        }
}
//prints the menu
void printMenu()
{
	printf("\n");
	printf("Welcome! Please input a command\n");
	printf("*******************************\n");
	printf("[1]	-> adds a song to playlist\n");
	printf("[2]	-> deletes a song from playlist\n");
	printf("[3]	-> view songs from playlist (first to last)\n");
	printf("[4]     -> view songs from playlist (last to first)\n");
	printf("[5]	-> exit program\n");
	printf("******************************\n");

	
}
void printStars()
{
	
	printf("******************************\n");
}
int main(int argc, char *argv[])
{	// create input buffer, head and tail of linked list
	char buffer[BUFFERSIZE];
	struct Song* first = NULL;
	struct Song* curr = NULL;
	struct Song* last = NULL;
	int command = 0;
	int songCount = 0;
// loop for menu functionality
	while (command != 5)
	{	// tmp locals to hold first and last
		struct Song* tmp = first;
		struct Song* tmp1 = last;
		int hnd;
		switch (command)
		{// prints menu, default
		case(0):
			printMenu();
			// call scanf to get command
			scanf("%d*", &command);
			//clears newline character after user pressed enter
			getchar();
			break;

		case(1):
			// adds a song to end of list
			printf("Please enter a song name: ");
			char* name;
			int len;
			// next 20 lines are handle user input
			if(fgets(buffer,BUFFERSIZE,stdin) != NULL)
			{
				len = (int)strlen(buffer);
				name = (char*)malloc(len+1);
				buffer[len-1] = '\0';
				strcpy(name,buffer);
			}
			printf("Please enter artist's name: ");
			char* artist;
			
			if(fgets(buffer,BUFFERSIZE,stdin)!=NULL)
			{
				len=strlen(buffer);
				buffer[len-1] = '\0';
				artist=malloc(len+1);
				strcpy(artist,buffer);
			}
			char* year;
			printf("Please enter year of song: ");
			if(fgets(buffer,BUFFERSIZE,stdin)!=NULL)
                        {
                                len=strlen(buffer);
                                buffer[len-1] = '\0';
                                year=malloc(len+1);
                                strcpy(year,buffer);
                        }
			printf("Please enter runtime: ");
			int runtime;
			scanf("%d*", &runtime);
			// add first song
			if (first == NULL)
			{
				first = Song(name,year,artist,runtime);
				printf("Added '%s by %s' to playlist!\n",name,artist);
				curr = first;
				songCount += 1;
				

			}
			else 
			{
				last = addSong(curr,year,runtime,name,artist);
				curr = last;
				songCount+=1;
				
			}
			command = 0;
			break;
		case(2):// delete song options
		
			 hnd = deleteSong(first,last);
			switch(hnd)
			{	// delete song returns 0, everything is fine, print menu
				case(0):
					command = 0;
					break;
				// song user entered not found, runs it again.
				case(1):
					command = 2;
					break;
				// deleting head of list
				case(2):
				// only one song in the list
					  if(songCount == 1)
                                        {
                                                first = NULL;
                                                last == NULL;
                                                deleteSongContents(tmp);
                                                free(tmp);
						songCount -=1;
                                                printf("Playlist now empty!\n");
                                        }
				// more than one in list
					else
					{
						first = first->next;
						first->prev = NULL;
						deleteSongContents(tmp);
						free(tmp);
						printf("Successfully deleted song\n");
						songCount -=1;
					}
					command = 0;
					break;
				case(3):
				// deleting tail of list
					if(songCount == 1)
					{
						first = NULL;
						last == NULL;
						deleteSongContents(tmp1);
						free(tmp1);
						songCount -=1;
						printf("Playlist now empty!\n");
					}
					else
					{
						last = last->prev;
						last->next = NULL;
						deleteSongContents(tmp1);
						free(tmp1);
						printf("Succesfully deleted song\n");
						songCount -= 1;
					}
					command = 0;
					break;
			}
			break;
		case(3):// prints the list from beginning to end
			printListf(first);
			command = 0;
			break;
		case(4): // prints list from end to beginning
			printListb(last);
			command = 0;
			break;
		}

		
	}
	return 0;
}
