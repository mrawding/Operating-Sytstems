#pragma once

struct Song {
	
	struct Song* prev;
	struct Song* next;
	int runTime;
	char* artistName;
	char* songName;
	char* year;
};
