#include <stdlib.h>

#include <string.h>

#include <strings.h>

#include <limits.h>

#include <unistd.h>

#include <glob.h>

#include <stdlib.h>

#include <pwd.h>

#include <dirent.h>

#include <sys/types.h>

#include <sys/wait.h>

#include <signal.h>

#include "sh.h"

#define BUFFERSIZE 255
extern char** environ;
int sh( int argc, char **argv, char **envp )
{

char *prompt = calloc(PROMPTMAX, sizeof(char));
 
  
char *command, *arg, *commandpath, *p, *pwd, *owd;
  
char **args = calloc(MAXARGS, sizeof(char*));
 
 int uid, i, status, argsct, go = 1;
  
struct passwd *password_entry;  
char *homedir;
  
struct pathelement *pathlist;

 
 uid = getuid();
  

    /* get passwd info */
password_entry = getpwuid(uid);
homedir = password_entry->pw_dir;
/* Home directory to start
out with*/
     

  if ( (pwd = getcwd(NULL, PATH_MAX+1)) == NULL )
  
{
    perror("getcwd");
 
   exit(2);
 
 }
  
owd = calloc(strlen(pwd) + 1, sizeof(char));
  
memcpy(owd, pwd, strlen(pwd));
 
prompt[0] = ' ';
prompt[1] = '\0';
char cmd1[6] = "prompt";
char cmd2[4] = "exit";
char cmd3[5] = "which";
char cmd4[5] = "where";
char cmd5[4] = "kill";
char cmd6[2] = "cd";
char cmd7[3] = "pwd";
char cmd8[4] = "list";
char cmd9[8] = "printenv";
char cmd10[6] = "setenv";
 
 /* Put PATH into a linked list */
 
pathlist = get_path();
char cwd[255];
char* cmd;
getcwd(pwd,0); 
 while ( go )
 
 {
   
 /* print your prompt */
 getcwd(cwd,sizeof(cwd));
 printf("%s[%s]>",prompt,cwd);
   
 /* get command line and process */
 char buffer[BUFFERSIZE];
        if(fgets(buffer,BUFFERSIZE,stdin) != NULL)
        {
                 int len = (int)strlen(buffer);
		 cmd = (char*)malloc(len + 1);
                 buffer[len-1] = '\0';
                 strcpy(cmd,buffer);
        }
int i = 0;
// tokenize by spaces, command goes into arg[0]
args[i] = strtok(cmd," ");
while(args[i]!=NULL)
{
	args[++i] = strtok(NULL," ");
}
i = 0;
if(args[0] != NULL)
{
int j = 1;
argsct = 0;
// loops through args to get count
while(args[j] != NULL)
        {
                argsct++;
		j++;
        }
}
if(args[0] == NULL)
{
}
// prompt command functionality
else if(strcmp(args[0],"prompt") == 0)
{	if(args[1] != NULL)
	{
		strcpy(prompt,args[1]);
	}
	else
	{
		printf("Enter a prompt: ");
		if(fgets(buffer,BUFFERSIZE,stdin) != NULL)
        	{
                 int len = (int)strlen(buffer);
                 buffer[len-1] = '\0';
                 strcpy(prompt,buffer);
        	}	
	}
}
// exit functionality, free all remaining heap elements and exit while(go)
else if(strcmp(args[0],"exit") == 0)
{
	free(args);
	free(pwd);
	free(owd);
	struct pathelement *tmp = pathlist;
	struct pathelement *tmp2;
	while(tmp != NULL)
	{
		tmp2 = tmp->next;
		free(tmp);
		tmp = tmp2;
	}
	
	pathlist = NULL;
	free(prompt);
	free(cmd);
	cmd = NULL;

	go = 0;
}
// cd functionality
else if(strcmp(args[0],"cd") == 0)
{
	if(args[1] == NULL)
	{
		if(chdir(homedir) < 0)
                {	
                        perror("chdir failed");

                }
		else{
			//stores cwd as pwd for cd -
			strcpy(pwd,cwd);
		}
	}
	else if(strcmp(args[1],"-") == 0)
	{
		if(chdir(pwd) < 0)
                {
			perror("chdir failed");
                }
		else{
			strcpy(pwd,cwd);
		}
	}
	else{
		if(chdir(args[1]) < 0)
		{	
			perror("chdir failed");
		
		}
		else
		{
			strcpy(pwd,cwd);
		}
	}
}
// calls list function
else if(strcmp(args[0],"list") == 0)

{
	if(args[1] == NULL)
	{	
		list(cwd);
	}
	else{
		for(int i = 1; i <= argsct; i++)
		{
			printf("listing %s",args[i]);
			list(args[i]);
		}
	}
}
// where functionality
else if(strcmp(args[0],"where") == 0)
{
          if(args[1] ==  NULL)
        {
                printf("Too few arguments.\n");
        }
        else
        {
                for(int i = 1;i <= argsct; i++)
                {
			// check if built in command
                        if((strcmp(args[i],cmd1) ==  0) || (strcmp(args[i],cmd2) ==  0) || (strcmp(args[i],cmd3) == 0)||
(strcmp(args[i],cmd4) == 0) || (strcmp(args[i],cmd5) == 0) || (strcmp(args[i],cmd6) == 0) || (strcmp(args[i],cmd7) == 0) || (strcmp(args[i],cmd8) == 0) || (strcmp(args[i],cmd9) == 0) || (strcmp(args[i],cmd10) == 0))
                        {
                                printf("%s is a built-in shell command\n", args[i]);
                        }
                        else
                        {

                                int flag;
                                if((flag = where(args[i],pathlist)) == 0)
                                {
			    		printf("Command not found!\n");
                                }
				else
				{
					printf("Executing built-in where\n");
				}
                        }
                }
        }
}
// which funcgtionality
else if(strcmp(args[0],"which") == 0)
{
	if(args[1] ==  NULL)
	{
		printf("Too few arguments.\n");
	}
	else
	{
		// loop through and which all args
		for(int i = 1;i <= argsct; i++)
		{
			// check to see if built in command
			if((strcmp(args[i],cmd1) ==  0) || (strcmp(args[i],cmd2) ==  0) || (strcmp(args[i],cmd3) == 0) ||(strcmp(args[i],cmd4) == 0) || (strcmp(args[i],cmd5) == 0) || (strcmp(args[i],cmd6) == 0) || (strcmp(args[i],cmd7) == 0) || (strcmp(args[i],cmd8) == 0) || (strcmp(args[i],cmd9) == 0) || (strcmp(args[i],cmd10) == 0))
			{
				printf("%s is a built-in shell command\n", args[i]);
			}
			else
			{
			
				printf("Executing built-in which\n");
				char *pathret;
				if((pathret = which(args[i],pathlist)) != NULL)
				{
					// gets path from which and strcopys it into buffer to be printed	
					char buf[255];
					strcpy(buf,pathret);
					strcat(buf,"/");
					strcat(buf,args[i]);
					printf("%s\n",buf);
				}
				else
				{
				printf("Command not found!\n");
				}
				pathret = NULL;
				
			}
		}
	}
}
// prints current workind directory
else if(strcmp(args[0],"pwd") == 0)
{
        printf("%s\n",cwd);
}

// prints the pid of the shell
else if(strcmp(args[0],"pid") == 0)
{
        if(argsct < 1)
	{
		printf("Executing built-in commmand 'pid'.\n");
		printf("PID: %d\n",(int)getpid());
	}
	else
	{
		printf("Built-in command 'pid' takes no arguments!\n");
	}


}
// kill, kills given pid or sends signal to another pid
else if(strcmp(args[0],"kill") == 0)
{
	if(argsct == 1)
	{
		pid_t tmp_pid = (pid_t)(atoi(args[1]));
		if(tmp_pid == 0 && strcmp(args[1],"0") != 0)
		{
			perror(args[1]);
		}
		else if(kill(tmp_pid,SIGKILL) != 0)
		{
			perror(args[1]);
		}
		else
		{
			printf("Executing built-in command 'kill'\n");
		}
	}
	else if(argsct == 2)
	{	
		args[1]++;
		pid_t tmp_pid = (pid_t)(atoi(args[2]));
		if(kill(tmp_pid,atoi(args[1])) !=0)
		{
			perror(args[1]);
		}
		else
		{
			printf("f\n");
		}
	}
			
	else
	{
		 printf("Built-in 'kill' takes 1 or 2 argumanets!\n");
	}
	
}// enter button pressed or CTRL + D
else if(args[0] == NULL)
{
}

// functionality to set ENV variables
else if(strcmp(args[0],"setenv") == 0)
{
	if(argsct < 1)
	{
		printf("Executing built-in 'setenv'\n");
	        int k = 0;
		while(environ[k] != NULL)
		{
			printf("%s\n",environ[k]);
			k++;
		}
		printf("\n");
	}
				           
	 else if (argsct == 1) {
			

			
		 char *buff = malloc(20);

		 strcpy(buff, args[1]);

		 if (setenv(buff, "", 1) != 0) 
		 {
			// setenv() error
			 perror(argv[0]);

		 }


		 free(buff);

	 } else if (argsct == 2) {

		 char *buff = malloc(20);

		 strcpy(buff, args[1]);

		 if (setenv(buff, args[2], 1) != 0) 
		 {

			 perror(argv[0]);

		 }

		 free(buff);

	 }
       	else
	{

	 printf("setenv: Too many arguments.\n");
	}
}
else if(strcmp(args[0],"printenv") == 0)
{
	printf("Executing built-in 'printenv'\n");
	int k = 0;
	while(environ[k] != NULL)
	{
		printf("%s\n",environ[k]);
		k++;
	}
	printf("\n");

} // not a built in command, check to see if ABSOLUTE PATH or command contained within a path allowing for wildcards
else
{	int status;
	int csource;
	int free_p_flag = 0;
	glob_t paths;
	pid_t pid;
	int wait_i;
	char **p;
	// check to see if given command is in the path or not
	if(access(args[0],X_OK) != 0)
	{
		int success_f = 0;
		char *tmp_cmd  = calloc(64,sizeof(char));
		struct pathelement *tmpPath = pathlist;
		// loops through the home path
		while(tmpPath)
		{	// similar to which/where
			sprintf(tmp_cmd,"%s/%s",tmpPath->element,args[0]);
			if(access(tmp_cmd,X_OK) == 0)
			{
				success_f = 1;
				printf("%s\n",tmp_cmd);
				break;
			}
			tmpPath = tmpPath->next;
		}
		// indicates that it is not a command or a directory
		if(success_f == 0)
		{
			perror(args[0]);
		}
		else{
			// wild card handler
			// sudo args is for passing wild cards to execv
			char ** sudo_args = calloc(MAXARGS,sizeof(char*));
			sudo_args[0] = tmp_cmd;
			int sudo_argsct = 1;
			char * tmp = NULL;
			for(int i = 1; i <= argsct; i++)
			{
				// function for replacing all '?'s with *'s
				tmp = replace_chars(args[i],"?","*");
				if(tmp != NULL)
				{
					strcpy(args[i],tmp);
					free(tmp);
					// wild card handler
					csource = glob(args[i],0,NULL,&paths);
					free_p_flag = 1;
					if(csource == 0)
					{ // feeds wildcard arguments into sudo args array
						for(int j = 0; j < paths.gl_pathc; j++)
						{
							sudo_args[sudo_argsct] = paths.gl_pathv[j];
							sudo_argsct++;
						}
					}

					// no wild card matches
					else if(csource == GLOB_NOMATCH)
					{
						sudo_args[sudo_argsct] = args[i];
						sudo_argsct++;
					}
					else
					{
						perror("Glob error");
					}
				}			
				else
				{
					sudo_args[sudo_argsct] = args[i];
					sudo_argsct++;

				}
			}
			// create child process
			pid = fork();
			if(pid < 0)
			{
				perror("fork failed");
				exit(1);
			}

			// execute the process and pass arguments to it
			else if(pid == 0) // child process
			{
				printf("executing %s\n",args[0]);
				execve(tmp_cmd,sudo_args,environ);
				perror(tmp_cmd);
				exit(1);
			}
			else // parent process
			{
				wait_i = waitpid(pid,&status,0);
				if(WEXITSTATUS(status) != 0)
				{
					printf("Exiting %d\n",WEXITSTATUS(status));
				 }
			}
			free(sudo_args);
			tmpPath = NULL;
			free(tmp);
			if(free_p_flag)
			{
				globfree(&paths);
			}
		}
		free(tmp_cmd);
		tmp_cmd = NULL;
		}
		else // absolute path
		{
			DIR *dir; 
			if((dir = opendir(args[0])) != NULL) // absolute path is a directory and not a .exe
			{
				printf("Permission Denied\n");
			}
			// Absolute path but not a directory
			// create child process

			pid = fork();
			// fork failure catch
			if(pid < 0)
			{
				perror("fork failed");
			}
			// child proc created
	       		else if(pid == 0)
			{	
				char* tmp = args[0];  
			     // shift args over because arg[0] is the executable path, rest are args	
				args++;  
				execve(tmp,args,environ);    
			}
			else
			{
				// for exiting process
			int wait_i = waitpid(pid,&status,0);

				if(WEXITSTATUS(status) != 0)
				{
					printf("Exiting: %d\n",WEXITSTATUS(status));
				}	
			}

		}

}
// free cmd on heap
free(cmd);
cmd = NULL;
  
}
  return 0;
} 
/* sh() */
// finda and replaces a specific/unique character in a string with anoter
char* replace_chars(char *inp_str,char *out, char*in)
{
	char *result;
	char *tmp;
	char *rep;
	int out_len = strlen(out);
	int in_len = strlen(in);
	int ct;
	int btwn;
	if(out_len == 0)
	{
		result = NULL;
		return result;
	}
	if(!in)
	{
		in = "";
	}
	rep = inp_str;
	// countint occurences of ? in *
	for(ct = 0; tmp = strstr(rep,out); ++ ct)
	{
		rep = tmp + out_len;
	}
	tmp = result = malloc(strlen(inp_str)+(in_len - out_len) * ct + 1);
	if(!result)
	{
		return result;
	}
	while(ct--)
	{
		// returns pointer to furst occurebce of out in inp_str
		rep = strstr(inp_str,out);
		// characters between
		btwn = rep - inp_str;
		// string copt to tmp by btwn characters in in inp_str
		tmp  = strncpy(tmp,inp_str,btwn) + btwn;
		tmp = strcpy(tmp,in) + in_len;
		inp_str += btwn + out_len;
	}
	strcpy(tmp,inp_str);
	return result;
}

int where(char *command, struct pathelement *pathlist )
{
char cmd[255];
int flag = 0;
struct pathelement *p = pathlist;
  while (p) {
    sprintf(cmd, "%s/%s", p->element,command);
	    if (access(cmd, X_OK) == 0) {
       		 printf("%s\n", p->element);
       		 flag = 1;
    		}
    p = p->next;
   }
  return flag;
   /* loop through pathlist until finding command and return it.  Return
   NULL when not found. */

} /* where() */

char *which(char *command, struct pathelement *pathlist )
{
  /* similarly loop through finding all locations of command */
  char cmd[255];
  struct pathelement *p = pathlist;
  while (p) { 
    sprintf(cmd, "%s/%s", p->element,command);        
    if (access(cmd, X_OK) == 0) {
	return p->element;
	break;
	
    }
    p = p->next;
  }
  return NULL;
} /* which() */

void list ( char *dir )
{
  /* see man page for opendir() and readdir() and print out filenames for
  the directory passed */
  DIR* directory;
  struct dirent* dp;
  directory = opendir(dir);
  
  if(directory == NULL)
  {
	perror(dir);
  }
  else
  {
	while((dp = readdir(directory)) != NULL)
	{
		printf("%s\n",dp->d_name);
		fflush(stdout);
	}
	closedir(directory);			
 }
  
} /* list() */


